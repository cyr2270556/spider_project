package constants

const (
	EngineScrapy = "scrapy"
	EngineColly  = "colly"
)
