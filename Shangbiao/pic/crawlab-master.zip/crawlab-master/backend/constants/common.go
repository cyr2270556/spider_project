package constants

const (
	ASCENDING = "ascending"
	DESCENDING = "descending"
)
