package constants

const (
	MsgTypeGetLog        = "get-log"
	MsgTypeGetSystemInfo = "get-sys-info"
	MsgTypeCancelTask    = "cancel-task"
	MsgTypeRemoveLog     = "remove-log"
	MsgTypeRemoveSpider  = "remove-spider"
)
