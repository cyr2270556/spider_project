package constants

const ScrapyProtectedStageNames = ""

const ScrapyProtectedFieldNames = "_id,task_id,ts"
