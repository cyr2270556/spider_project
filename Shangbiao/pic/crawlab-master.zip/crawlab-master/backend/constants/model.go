package constants

const (
	ObjectIdNull = "000000000000000000000000"
	Infinite     = 999999999
)
