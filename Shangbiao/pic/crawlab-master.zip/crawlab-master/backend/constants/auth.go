package constants

const (
	OwnerTypeAll    = "all"
	OwnerTypeMe     = "me"
	OwnerTypePublic = "public"
)
