---
name: Bug 报告
about: 创建一份 Bug 报告帮助我们优化产品
title: ''
labels: 'bug'
assignees: ''

---

**Bug 描述**
例如，当 xxx 时，xxx 功能不工作。

**复现步骤**
该 Bug 复现步骤如下
1. 
2. 
3. 

**期望结果**
xxx 能工作。

**截屏**
![截屏1](http://static-docs.crawlab.cn/login.png)
