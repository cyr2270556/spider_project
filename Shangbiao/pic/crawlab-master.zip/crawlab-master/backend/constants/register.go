package constants

const (
	RegisterTypeMac      = "mac"
	RegisterTypeIp       = "ip"
	RegisterTypeHostname = "hostname"
	RegisterTypeCustomName = "customName"
)
