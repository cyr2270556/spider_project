package constants

const (
	StatusOnline  = "online"
	StatusOffline = "offline"
)
