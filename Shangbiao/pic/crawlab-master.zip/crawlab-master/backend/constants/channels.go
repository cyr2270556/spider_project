package constants

const (
	ChannelAllNode = "nodes:public"

	ChannelWorkerNode = "nodes:"

	ChannelMasterNode = "nodes:master"
)
