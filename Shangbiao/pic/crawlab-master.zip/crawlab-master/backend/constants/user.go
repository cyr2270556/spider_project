package constants

const (
	RoleAdmin  = "admin"
	RoleNormal = "normal"
)
