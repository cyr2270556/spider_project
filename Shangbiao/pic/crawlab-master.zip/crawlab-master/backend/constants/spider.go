package constants

const (
	Customized   = "customized"
	Configurable = "configurable"
	Plugin       = "plugin"
)
