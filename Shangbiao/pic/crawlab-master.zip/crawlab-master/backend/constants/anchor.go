package constants

const (
	AnchorStartStage = "START_STAGE"
	AnchorStartUrl   = "START_URL"
	AnchorItems      = "ITEMS"
	AnchorParsers    = "PARSERS"
)
