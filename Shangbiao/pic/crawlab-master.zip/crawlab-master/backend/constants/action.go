package constants

const (
	ActionTypeVisit          = "visit"
	ActionTypeInstallDep     = "install_dep"
	ActionTypeInstallLang    = "install_lang"
	ActionTypeViewDisclaimer = "view_disclaimer"
)
