package model

type Base struct {
}

func (b *Base) Save() error {
	return nil
}

func (b *Base) Delete() error {
	return nil
}
