package constants

const (
	String  = "string"
	Number  = "number"
	Boolean = "boolean"
	Array   = "array"
	Object  = "object"
)
