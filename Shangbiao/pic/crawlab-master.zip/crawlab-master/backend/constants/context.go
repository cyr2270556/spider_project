package constants

const (
	ContextUser = "currentUser"
)
